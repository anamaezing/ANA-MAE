<?php
$title = 'Index';
require_once 'includes/header.php';
?>

<h1 class="text-center" style="color: green;">Registration for IT Conference</h1>


<form>
<form action="/action_page.php">
  <label for="fname"><b>First Name:</b></label><br>
  <input type="text" id="fname" name="fname" value=""><br>
  <label for="lname"><b>Last Name:</b></label><br>
  <input type="text" id="lname" name="lname" value=""><br><br>
</form> 

<form>
<form action="/action_page.php">
  <label for="birthday"><b>Birthday:</b></label>
  <input type="date" id="birthday" name="birthday">
</form>

<form>
<form action="/action_page.php">
<div class="form-group">
    <label for="Select"><b>Specialty:</b></label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>Database Admin</option>
      <option>Software Developer</option>
      <option>Web Developer</option>
      <option>Other</option>
    </select>
  </div>
</form>

<form>
  <div class="form-group">
    <label for="exampleFormControlInput1"><b>Email address:</b></label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="">
  </div>
</form>

  <form>
  <div class="form-group">
    <label for="exampleFormControlInput1"><b>Contact Number:</b></label>
    <input type="contact-number" class="form-control" id="exampleFormControlInput1" placeholder="">
  </div>
</form>

<form>
<form action="/action_page.php">
<div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="Check1">
    <label class="form-check-label" for="Check1"><b>Check me out</b></label>  
</div>
  <button type="submit" class="btn btn-primary"><i>Submit</i></button>
</form>

<?php require_once 'includes/footer.php'?>

